import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Loader2, AlertTriangle, CheckCircle, TrendingUp, Factory, Gauge } from "lucide-react";
import { format } from "date-fns";
import type { Prediction } from "@shared/schema";

export default function History() {
  const { data: predictions, isLoading, error } = useQuery({
    queryKey: ["predictions"],
    queryFn: async () => {
      const response = await fetch("/api/predictions");
      if (!response.ok) throw new Error("Failed to fetch predictions");
      return response.json() as Promise<Prediction[]>;
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="text-center space-y-4">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto" />
          <p className="text-muted-foreground">Loading prediction history...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="text-center space-y-4 text-destructive">
          <AlertTriangle className="h-12 w-12 mx-auto" />
          <p>Failed to load predictions</p>
        </div>
      </div>
    );
  }

  const stats = predictions ? {
    total: predictions.length,
    defects: predictions.filter(p => p.defectStatus === 1).length,
    noDefects: predictions.filter(p => p.defectStatus === 0).length,
    avgProbability: predictions.length > 0 
      ? (predictions.reduce((acc, p) => acc + p.probability, 0) / predictions.length).toFixed(1)
      : "0",
  } : { total: 0, defects: 0, noDefects: 0, avgProbability: "0" };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Prediction History</h1>
        <p className="text-muted-foreground mt-1">Complete log of all defect predictions and analyses.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="bg-card/50 backdrop-blur border-white/5">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Predictions</p>
                <p className="text-2xl font-bold font-mono mt-1">{stats.total}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur border-white/5">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Defects Predicted</p>
                <p className="text-2xl font-bold font-mono mt-1 text-destructive">{stats.defects}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-destructive" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur border-white/5">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">No Defects</p>
                <p className="text-2xl font-bold font-mono mt-1 text-emerald-500">{stats.noDefects}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-emerald-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50 backdrop-blur border-white/5">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg. Probability</p>
                <p className="text-2xl font-bold font-mono mt-1">{stats.avgProbability}%</p>
              </div>
              <Gauge className="h-8 w-8 text-warning" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Predictions Table */}
      <Card className="bg-card/50 backdrop-blur border-white/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Factory className="w-5 h-5 text-primary" />
            All Predictions
          </CardTitle>
          <CardDescription>Chronological list of defect probability analyses</CardDescription>
        </CardHeader>
        <CardContent>
          {predictions && predictions.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p>No predictions yet. Run your first analysis to get started.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {predictions?.map((prediction) => (
                <div
                  key={prediction.id}
                  data-testid={`prediction-${prediction.id}`}
                  className="p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors border border-white/5"
                >
                  <div className="flex items-start justify-between gap-4 flex-wrap">
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        "w-10 h-10 rounded-full flex items-center justify-center",
                        prediction.defectStatus === 1 
                          ? "bg-destructive/20 text-destructive" 
                          : "bg-emerald-500/20 text-emerald-500"
                      )}>
                        {prediction.defectStatus === 1 ? (
                          <AlertTriangle className="w-5 h-5" />
                        ) : (
                          <CheckCircle className="w-5 h-5" />
                        )}
                      </div>
                      
                      <div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className={cn(
                            "text-xs font-bold",
                            prediction.defectStatus === 1 
                              ? "border-destructive text-destructive" 
                              : "border-emerald-500 text-emerald-500"
                          )}>
                            {prediction.defectStatus === 1 ? "DEFECT" : "OK"}
                          </Badge>
                          <span className="text-sm font-mono text-muted-foreground">
                            {prediction.probability.toFixed(1)}% probability
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          {format(new Date(prediction.timestamp), "MMM dd, yyyy 'at' HH:mm")}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-4 text-xs">
                      <div className="bg-white/5 rounded px-2 py-1">
                        <span className="text-muted-foreground">Volume:</span>{" "}
                        <span className="font-mono">{prediction.productionVolume}</span>
                      </div>
                      <div className="bg-white/5 rounded px-2 py-1">
                        <span className="text-muted-foreground">Quality:</span>{" "}
                        <span className="font-mono">{prediction.qualityScore?.toFixed(1)}</span>
                      </div>
                      <div className="bg-white/5 rounded px-2 py-1">
                        <span className="text-muted-foreground">Defect Rate:</span>{" "}
                        <span className="font-mono">{prediction.defectRate?.toFixed(2)}%</span>
                      </div>
                      <div className="bg-white/5 rounded px-2 py-1">
                        <span className="text-muted-foreground">Downtime:</span>{" "}
                        <span className="font-mono">{prediction.downtimePercentage?.toFixed(2)}%</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}