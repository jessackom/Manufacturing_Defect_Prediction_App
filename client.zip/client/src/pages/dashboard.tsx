import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Activity, AlertTriangle, CheckCircle, Factory, TrendingUp, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import type { Prediction } from "@shared/schema";
import { format } from "date-fns";

function MetricCard({ title, value, icon: Icon, trend, trendUp, valueColor }: { title: string, value: string, icon: any, trend?: string, trendUp?: boolean, valueColor?: string }) {
  return (
    <Card className="bg-card/50 backdrop-blur border-white/5">
      <CardContent className="p-6">
        <div className="flex items-center justify-between space-y-0 pb-2">
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <Icon className="h-4 w-4 text-primary" />
        </div>
        <div className="flex items-end justify-between">
            <div className={cn("text-2xl font-bold font-mono", valueColor)}>{value}</div>
            {trend && (
                <div className={cn("text-xs flex items-center", trendUp ? "text-emerald-500" : "text-rose-500")}>
                    {trend}
                </div>
            )}
        </div>
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  const { data: predictions, isLoading } = useQuery({
    queryKey: ["predictions"],
    queryFn: async () => {
      const response = await fetch("/api/predictions");
      if (!response.ok) throw new Error("Failed to fetch predictions");
      return response.json() as Promise<Prediction[]>;
    },
  });

  const stats = predictions ? {
    total: predictions.length,
    defects: predictions.filter(p => p.defectStatus === 1).length,
    noDefects: predictions.filter(p => p.defectStatus === 0).length,
    defectRate: predictions.length > 0 
      ? ((predictions.filter(p => p.defectStatus === 1).length / predictions.length) * 100).toFixed(1)
      : "0",
  } : { total: 0, defects: 0, noDefects: 0, defectRate: "0" };

  const pieData = [
    { name: 'Defect', value: stats.defects, color: 'hsl(var(--destructive))' },
    { name: 'No Defect', value: stats.noDefects, color: 'hsl(142, 71%, 45%)' },
  ].filter(d => d.value > 0);

  const trendData = predictions?.slice(0, 10).reverse().map((p, i) => ({
    name: format(new Date(p.timestamp), "HH:mm"),
    probability: p.probability,
    defectStatus: p.defectStatus,
  })) || [];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Manufacturing Overview</h1>
            <p className="text-muted-foreground mt-1">Real-time defect prediction monitoring and analysis.</p>
        </div>
        <div className="flex items-center space-x-2">
            <Badge variant="outline" className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20 px-3 py-1">
                <div className="w-2 h-2 rounded-full bg-emerald-500 mr-2 animate-pulse" />
                Model Active
            </Badge>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard 
          title="Total Predictions" 
          value={stats.total.toString()} 
          icon={Activity} 
        />
        <MetricCard 
          title="Defects Detected" 
          value={stats.defects.toString()} 
          icon={AlertTriangle} 
          valueColor="text-destructive"
        />
        <MetricCard 
          title="Normal Operations" 
          value={stats.noDefects.toString()} 
          icon={CheckCircle} 
          valueColor="text-emerald-500"
        />
        <MetricCard 
          title="Defect Rate" 
          value={`${stats.defectRate}%`} 
          icon={TrendingUp} 
          valueColor={parseFloat(stats.defectRate) > 50 ? "text-destructive" : "text-emerald-500"}
        />
      </div>

      {/* Main Content */}
      <div className="grid gap-4 md:grid-cols-7">
        {/* Trend Chart */}
        <Card className="col-span-4 bg-card/50 backdrop-blur border-white/5">
          <CardHeader>
            <CardTitle>Probability Trend</CardTitle>
            <CardDescription>Recent prediction probabilities over time</CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            {isLoading ? (
              <div className="h-[300px] flex items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : trendData.length > 0 ? (
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trendData}>
                    <defs>
                      <linearGradient id="colorProb" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                    <XAxis 
                      dataKey="name" 
                      stroke="#888888" 
                      fontSize={12} 
                      tickLine={false} 
                      axisLine={false} 
                    />
                    <YAxis 
                      stroke="#888888" 
                      fontSize={12} 
                      tickLine={false} 
                      axisLine={false} 
                      domain={[0, 100]}
                      tickFormatter={(value) => `${value}%`} 
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px' }}
                      itemStyle={{ color: 'hsl(var(--foreground))' }}
                      formatter={(value: number) => [`${value.toFixed(1)}%`, 'Probability']}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="probability" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={2}
                      fillOpacity={1} 
                      fill="url(#colorProb)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-[300px] flex flex-col items-center justify-center text-muted-foreground">
                <Factory className="h-12 w-12 mb-4 opacity-50" />
                <p>No predictions yet</p>
                <Link href="/predict">
                  <Button variant="outline" className="mt-4">Run First Prediction</Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pie Chart & Quick Actions */}
        <Card className="col-span-3 bg-card/50 backdrop-blur border-white/5">
          <CardHeader>
            <CardTitle>Defect Distribution</CardTitle>
            <CardDescription>Breakdown of prediction outcomes</CardDescription>
          </CardHeader>
          <CardContent>
            {pieData.length > 0 ? (
              <div className="h-[200px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-[200px] flex items-center justify-center text-muted-foreground text-sm">
                Run predictions to see distribution
              </div>
            )}

            <div className="flex justify-center gap-4 mt-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-destructive" />
                <span className="text-xs text-muted-foreground">Defect ({stats.defects})</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-emerald-500" />
                <span className="text-xs text-muted-foreground">No Defect ({stats.noDefects})</span>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-white/10">
              <Link href="/predict">
                <Button className="w-full" data-testid="button-new-prediction">
                  <Activity className="w-4 h-4 mr-2" />
                  New Prediction
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Predictions */}
      {predictions && predictions.length > 0 && (
        <Card className="bg-card/50 backdrop-blur border-white/5">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Recent Predictions</CardTitle>
              <CardDescription>Latest defect analyses from your model</CardDescription>
            </div>
            <Link href="/history">
              <Button variant="outline" size="sm">View All</Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {predictions.slice(0, 5).map((prediction) => (
                <div key={prediction.id} className="flex items-center justify-between p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors border border-white/5">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-2 h-2 rounded-full",
                      prediction.defectStatus === 1 ? "bg-destructive animate-pulse" : "bg-emerald-500"
                    )} />
                    <div>
                      <div className="font-medium text-sm">
                        {prediction.defectStatus === 1 ? "Defect Predicted" : "Normal Operation"}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Vol: {prediction.productionVolume} | Quality: {prediction.qualityScore?.toFixed(0)}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={cn(
                      "font-mono font-bold text-sm",
                      prediction.probability > 70 ? "text-destructive" : "text-foreground"
                    )}>
                      {prediction.probability.toFixed(1)}%
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {format(new Date(prediction.timestamp), "HH:mm")}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}