import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Loader2, AlertCircle, CheckCircle2, Activity, Factory, Gauge, Users, Truck, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface PredictionParams {
  productionVolume: number;
  productionCost: number;
  downtimePercentage: number;
  supplierQuality: number;
  qualityScore: number;
  defectRate: number;
  maintenanceHours: number;
  workerProductivity: number;
  safetyIncidents: number;
  deliveryDelay: number;
  inventoryTurnover: number;
  stockoutRate: number;
  energyConsumption: number;
  energyEfficiency: number;
  additiveProcessTime: number;
  additiveMaterialCost: number;
}

const defaultParams: PredictionParams = {
  productionVolume: 500,
  productionCost: 12000,
  downtimePercentage: 2.5,
  supplierQuality: 90,
  qualityScore: 85,
  defectRate: 2.0,
  maintenanceHours: 10,
  workerProductivity: 90,
  safetyIncidents: 2,
  deliveryDelay: 2,
  inventoryTurnover: 5.0,
  stockoutRate: 0.04,
  energyConsumption: 2500,
  energyEfficiency: 0.3,
  additiveProcessTime: 5.0,
  additiveMaterialCost: 250,
};

export default function Predict() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<{ defectStatus: number; probability: number } | null>(null);
  const [params, setParams] = useState<PredictionParams>(defaultParams);

  const updateParam = (key: keyof PredictionParams, value: string) => {
    const numValue = parseFloat(value) || 0;
    setParams(prev => ({ ...prev, [key]: numValue }));
  };

  const savePredictionMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch("/api/predictions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to save prediction");
      return response.json();
    },
    onSuccess: () => {
      toast.success("Prediction saved to history");
    },
    onError: () => {
      toast.error("Failed to save prediction");
    },
  });

  const handleAnalyze = () => {
    setIsAnalyzing(true);
    setResult(null);
    
    setTimeout(() => {
      // Simulate model inference based on key risk factors
      const riskScore = 
        (params.defectRate / 5) * 0.25 +
        (params.downtimePercentage / 10) * 0.15 +
        ((100 - params.supplierQuality) / 20) * 0.15 +
        ((100 - params.qualityScore) / 40) * 0.15 +
        (params.safetyIncidents / 10) * 0.1 +
        (params.deliveryDelay / 5) * 0.1 +
        (params.stockoutRate / 0.1) * 0.1;

      const probability = Math.min(Math.max(riskScore * 100, 1), 99);
      const defectStatus = probability > 50 ? 1 : 0;

      setResult({ defectStatus, probability: Math.round(probability * 10) / 10 });
      setIsAnalyzing(false);
      
      savePredictionMutation.mutate({
        ...params,
        defectStatus,
        probability,
      });
    }, 1800);
  };

  const InputField = ({ label, paramKey, unit, icon: Icon }: { label: string; paramKey: keyof PredictionParams; unit?: string; icon?: any }) => (
    <div className="space-y-2">
      <Label className="text-xs text-muted-foreground flex items-center gap-1">
        {Icon && <Icon className="w-3 h-3" />}
        {label}
      </Label>
      <div className="relative">
        <Input
          type="number"
          value={params[paramKey]}
          onChange={(e) => updateParam(paramKey, e.target.value)}
          className="font-mono text-sm bg-white/5 border-white/10 pr-12"
          data-testid={`input-${paramKey}`}
        />
        {unit && (
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">
            {unit}
          </span>
        )}
      </div>
    </div>
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Defect Prediction</h1>
        <p className="text-muted-foreground mt-1">Enter manufacturing parameters to predict defect probability.</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Input Panel */}
        <div className="lg:col-span-2">
          <Card className="bg-card/50 backdrop-blur border-white/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Factory className="w-5 h-5 text-primary" />
                Manufacturing Parameters
              </CardTitle>
              <CardDescription>All 16 input features from your Databricks model</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="production" className="w-full">
                <TabsList className="grid w-full grid-cols-5 mb-6">
                  <TabsTrigger value="production" className="text-xs">Production</TabsTrigger>
                  <TabsTrigger value="quality" className="text-xs">Quality</TabsTrigger>
                  <TabsTrigger value="operations" className="text-xs">Operations</TabsTrigger>
                  <TabsTrigger value="supply" className="text-xs">Supply Chain</TabsTrigger>
                  <TabsTrigger value="energy" className="text-xs">Energy</TabsTrigger>
                </TabsList>

                <TabsContent value="production" className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <InputField label="Production Volume" paramKey="productionVolume" unit="units" icon={Factory} />
                    <InputField label="Production Cost" paramKey="productionCost" unit="$" />
                    <InputField label="Downtime %" paramKey="downtimePercentage" unit="%" />
                  </div>
                </TabsContent>

                <TabsContent value="quality" className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <InputField label="Supplier Quality" paramKey="supplierQuality" unit="/100" icon={Gauge} />
                    <InputField label="Quality Score" paramKey="qualityScore" unit="/100" />
                    <InputField label="Defect Rate" paramKey="defectRate" unit="%" />
                  </div>
                </TabsContent>

                <TabsContent value="operations" className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <InputField label="Maintenance Hours" paramKey="maintenanceHours" unit="hrs" icon={Users} />
                    <InputField label="Worker Productivity" paramKey="workerProductivity" unit="%" />
                    <InputField label="Safety Incidents" paramKey="safetyIncidents" unit="#" />
                  </div>
                </TabsContent>

                <TabsContent value="supply" className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <InputField label="Delivery Delay" paramKey="deliveryDelay" unit="days" icon={Truck} />
                    <InputField label="Inventory Turnover" paramKey="inventoryTurnover" unit="x" />
                    <InputField label="Stockout Rate" paramKey="stockoutRate" unit="%" />
                  </div>
                </TabsContent>

                <TabsContent value="energy" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <InputField label="Energy Consumption" paramKey="energyConsumption" unit="kWh" icon={Zap} />
                    <InputField label="Energy Efficiency" paramKey="energyEfficiency" unit="ratio" />
                  </div>
                  <Separator className="my-4 bg-white/10" />
                  <p className="text-xs text-muted-foreground mb-2">Additive Manufacturing</p>
                  <div className="grid grid-cols-2 gap-4">
                    <InputField label="Process Time" paramKey="additiveProcessTime" unit="hrs" />
                    <InputField label="Material Cost" paramKey="additiveMaterialCost" unit="$" />
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
            <CardFooter>
              <Button 
                data-testid="button-run-prediction"
                className="w-full font-bold text-md h-12" 
                onClick={handleAnalyze}
                disabled={isAnalyzing}
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Running Model Inference...
                  </>
                ) : (
                  "Predict Defect Status"
                )}
              </Button>
            </CardFooter>
          </Card>
        </div>

        {/* Results Panel */}
        <div>
          <Card className={cn(
            "h-full transition-all duration-500 border-white/5 overflow-hidden relative min-h-[400px]",
            result ? "bg-card/50" : "bg-card/20 border-dashed"
          )}>
            {!result && !isAnalyzing && (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground/50 p-8 text-center">
                <div className="w-16 h-16 rounded-full border-2 border-dashed border-muted-foreground/30 mb-4 flex items-center justify-center">
                  <Activity className="w-8 h-8" />
                </div>
                <p className="text-sm">Enter parameters and run prediction</p>
              </div>
            )}

            {isAnalyzing && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-card/80 backdrop-blur-sm z-10">
                <div className="text-primary font-mono text-lg animate-pulse">Processing 16 Features...</div>
                <Progress value={66} className="w-[60%] mt-4 h-2" />
              </div>
            )}

            {result && (
              <CardContent className="h-full flex flex-col justify-center py-8 animate-in zoom-in-95 duration-300">
                <div className="text-center space-y-3 mb-8">
                  <h3 className="text-muted-foreground text-sm uppercase tracking-widest">Defect Status</h3>
                  
                  <div className={cn(
                    "w-24 h-24 rounded-full mx-auto flex items-center justify-center",
                    result.defectStatus === 1 
                      ? "bg-destructive/20 border-2 border-destructive" 
                      : "bg-emerald-500/20 border-2 border-emerald-500"
                  )}>
                    {result.defectStatus === 1 ? (
                      <AlertCircle className="w-12 h-12 text-destructive" />
                    ) : (
                      <CheckCircle2 className="w-12 h-12 text-emerald-500" />
                    )}
                  </div>

                  <Badge variant="outline" className={cn(
                    "px-4 py-2 text-lg font-bold border-2",
                    result.defectStatus === 1 
                      ? "border-destructive text-destructive bg-destructive/10" 
                      : "border-emerald-500 text-emerald-500 bg-emerald-500/10"
                  )} data-testid="badge-status">
                    {result.defectStatus === 1 ? "DEFECT LIKELY" : "NO DEFECT"}
                  </Badge>

                  <div className="pt-4">
                    <p className="text-xs text-muted-foreground mb-1">Probability Score</p>
                    <div className={cn(
                      "text-4xl font-bold font-mono",
                      result.probability > 70 ? "text-destructive" : 
                      result.probability > 40 ? "text-warning" : "text-emerald-500"
                    )} data-testid="text-probability">
                      {result.probability}%
                    </div>
                  </div>
                </div>

                <Separator className="bg-white/10 my-4" />

                <div className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Model Confidence</span>
                      <span className="text-muted-foreground font-mono">94.7%</span>
                    </div>
                    <Progress value={94.7} className="h-1" />
                  </div>

                  <div className="bg-white/5 rounded-lg p-3 space-y-2 mt-4">
                    <h4 className="text-xs font-medium text-muted-foreground">Key Risk Factors</h4>
                    <ul className="text-xs space-y-1">
                      {params.defectRate > 3 && (
                        <li className="text-warning">• High defect rate: {params.defectRate.toFixed(1)}%</li>
                      )}
                      {params.supplierQuality < 85 && (
                        <li className="text-warning">• Low supplier quality: {params.supplierQuality.toFixed(0)}</li>
                      )}
                      {params.downtimePercentage > 3 && (
                        <li className="text-warning">• Excessive downtime: {params.downtimePercentage.toFixed(1)}%</li>
                      )}
                      {params.safetyIncidents > 5 && (
                        <li className="text-warning">• High safety incidents: {params.safetyIncidents}</li>
                      )}
                      {params.defectRate <= 3 && params.supplierQuality >= 85 && params.downtimePercentage <= 3 && params.safetyIncidents <= 5 && (
                        <li className="text-emerald-500 flex items-center">
                          <CheckCircle2 className="w-3 h-3 mr-1" /> Parameters within normal range
                        </li>
                      )}
                    </ul>
                  </div>
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}