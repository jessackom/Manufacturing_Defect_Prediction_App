import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { LayoutDashboard, Activity, History, Settings, Bell, Menu, X } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import logoImage from "@assets/generated_images/minimalist_manufacturing_precision_logo.png";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navigation = [
    { name: "Dashboard", href: "/", icon: LayoutDashboard },
    { name: "Predict Defects", href: "/predict", icon: Activity },
    { name: "History", href: "/history", icon: History },
    { name: "Settings", href: "/settings", icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-background font-sans text-foreground flex">
      {/* Sidebar Desktop */}
      <aside className="hidden md:flex w-64 flex-col border-r border-sidebar-border bg-sidebar">
        <div className="h-16 flex items-center px-6 border-b border-sidebar-border">
          <img src={logoImage} alt="Logo" className="h-8 w-8 mr-3" />
          <span className="font-mono font-bold text-lg tracking-tight text-sidebar-foreground">
            DefectGuard<span className="text-primary">AI</span>
          </span>
        </div>
        
        <nav className="flex-1 py-6 px-4 space-y-1">
          {navigation.map((item) => {
            const isActive = location === item.href;
            return (
              <Link key={item.name} href={item.href}>
                <div
                  className={cn(
                    "flex items-center px-4 py-3 text-sm font-medium rounded-md transition-colors cursor-pointer group",
                    isActive
                      ? "bg-sidebar-accent text-primary border-l-2 border-primary"
                      : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-foreground"
                  )}
                >
                  <item.icon
                    className={cn(
                      "mr-3 h-5 w-5 transition-colors",
                      isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"
                    )}
                  />
                  {item.name}
                </div>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-sidebar-border">
          <div className="flex items-center p-3 rounded-lg bg-sidebar-accent/50">
            <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold mr-3">
              OP
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">Operator #42</p>
              <p className="text-xs text-muted-foreground truncate">Shift A - Line 3</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Header & Content */}
      <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
        <header className="md:hidden h-16 border-b border-border bg-background flex items-center justify-between px-4">
          <div className="flex items-center">
             <img src={logoImage} alt="Logo" className="h-8 w-8 mr-2" />
             <span className="font-mono font-bold text-lg">DefectGuard</span>
          </div>
          <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X /> : <Menu />}
          </Button>
        </header>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden fixed inset-0 z-50 bg-background/95 backdrop-blur-sm pt-20 px-4">
             <nav className="space-y-2">
              {navigation.map((item) => (
                <Link key={item.name} href={item.href} onClick={() => setIsMobileMenuOpen(false)}>
                  <div className={cn(
                    "flex items-center px-4 py-4 rounded-lg text-lg font-medium",
                     location === item.href ? "bg-accent text-accent-foreground" : "text-foreground"
                  )}>
                    <item.icon className="mr-4 h-6 w-6" />
                    {item.name}
                  </div>
                </Link>
              ))}
             </nav>
          </div>
        )}

        <main className="flex-1 overflow-auto p-4 md:p-8 relative">
            {/* Background Grid Pattern */}
            <div className="absolute inset-0 pointer-events-none opacity-[0.03]" 
                 style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '24px 24px' }}>
            </div>
            <div className="max-w-7xl mx-auto relative z-10">
                {children}
            </div>
        </main>
      </div>
    </div>
  );
}