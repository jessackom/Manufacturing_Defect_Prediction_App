// Types
export interface SensorData {
  timestamp: string;
  temperature: number;
  pressure: number;
  vibration: number;
  speed: number;
}

export interface DefectRecord {
  id: string;
  timestamp: string;
  probability: number;
  status: "Normal" | "Warning" | "Critical";
  factors: string[];
}

// Mock Data Generators
export const generateRealtimeData = (count: number): SensorData[] => {
  const data: SensorData[] = [];
  const now = new Date();
  for (let i = count; i > 0; i--) {
    const time = new Date(now.getTime() - i * 60000); // 1 min intervals
    data.push({
      timestamp: time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      temperature: 65 + Math.random() * 15 + (Math.random() > 0.8 ? 10 : 0), // Base 65-80, occasional spikes
      pressure: 100 + Math.random() * 20,
      vibration: 0.5 + Math.random() * 0.8,
      speed: 1200 + Math.random() * 100,
    });
  }
  return data;
};

export const recentAlerts: DefectRecord[] = [
  { id: "ALT-001", timestamp: "10:42 AM", probability: 88, status: "Critical", factors: ["High Vibration", "Temp Spike"] },
  { id: "ALT-002", timestamp: "09:15 AM", probability: 45, status: "Warning", factors: ["Pressure Drop"] },
  { id: "ALT-003", timestamp: "08:30 AM", probability: 12, status: "Normal", factors: [] },
  { id: "ALT-004", timestamp: "Yesterday", probability: 92, status: "Critical", factors: ["Bearing Noise"] },
];

export const systemHealth = {
  uptime: "99.8%",
  activeSensors: "24/24",
  totalPredictions: "14,205",
  efficiency: "94%"
};