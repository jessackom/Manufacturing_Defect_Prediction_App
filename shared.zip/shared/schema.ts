import { sql } from "drizzle-orm";
import { pgTable, text, varchar, serial, timestamp, real, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const predictions = pgTable("predictions", {
  id: serial("id").primaryKey(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  
  // Production Metrics
  productionVolume: integer("production_volume").notNull(),
  productionCost: real("production_cost").notNull(),
  downtimePercentage: real("downtime_percentage").notNull(),
  
  // Quality Indicators
  supplierQuality: real("supplier_quality").notNull(),
  qualityScore: real("quality_score").notNull(),
  defectRate: real("defect_rate").notNull(),
  
  // Operational Data
  maintenanceHours: integer("maintenance_hours").notNull(),
  workerProductivity: real("worker_productivity").notNull(),
  safetyIncidents: integer("safety_incidents").notNull(),
  
  // Supply Chain
  deliveryDelay: integer("delivery_delay").notNull(),
  inventoryTurnover: real("inventory_turnover").notNull(),
  stockoutRate: real("stockout_rate").notNull(),
  
  // Energy & Additive Manufacturing
  energyConsumption: real("energy_consumption").notNull(),
  energyEfficiency: real("energy_efficiency").notNull(),
  additiveProcessTime: real("additive_process_time").notNull(),
  additiveMaterialCost: real("additive_material_cost").notNull(),
  
  // Prediction Result
  defectStatus: integer("defect_status").notNull(), // 0 = No Defect, 1 = Defect
  probability: real("probability").notNull(),
  
  // Metadata
  operator: text("operator").default("Operator #42"),
  line: text("line").default("Line 3"),
});

export const insertPredictionSchema = createInsertSchema(predictions).omit({
  id: true,
  timestamp: true,
});

export type InsertPrediction = z.infer<typeof insertPredictionSchema>;
export type Prediction = typeof predictions.$inferSelect;
